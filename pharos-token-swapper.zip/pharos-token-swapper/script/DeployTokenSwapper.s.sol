// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "forge-std/Script.sol";
import "../src/swap/TokenSwapper.sol";

/**
 * @title DeployTokenSwapper
 * @notice Foundry deploy script for the Pharos Token Swapper skill.
 *
 * Usage:
 *   forge script script/DeployTokenSwapper.s.sol:DeployTokenSwapper \
 *     --rpc-url $RPC \
 *     --private-key $PRIVATE_KEY \
 *     --broadcast
 *
 * Set ROUTER_ADDRESS env var or update the default below for your DEX.
 */
contract DeployTokenSwapper is Script {
    // Default: update this to the DEX router address on Pharos
    // Check assets/tokens.json for the current router address
    address constant DEFAULT_ROUTER = 0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506; // SushiSwap-style router placeholder

    function run() external {
        address router = vm.envOr("ROUTER_ADDRESS", DEFAULT_ROUTER);

        vm.startBroadcast();

        TokenSwapper swapper = new TokenSwapper(router);

        vm.stopBroadcast();

        console.log("=== Pharos Token Swapper Deployed ===");
        console.log("Contract address:", address(swapper));
        console.log("Router used:     ", router);
        console.log("Owner:           ", swapper.owner());
        console.log("");
        console.log("Next step — verify (wait 10s first):");
        console.log(
            string.concat(
                "forge verify-contract ",
                vm.toString(address(swapper)),
                " src/swap/TokenSwapper.sol:TokenSwapper ",
                "--chain-id 688689 ",
                "--verifier-url https://api.socialscan.io/pharos-atlantic-testnet/v1/explorer/command_api/contract ",
                "--verifier blockscout ",
                "--constructor-args $(cast abi-encode 'constructor(address)' ",
                vm.toString(router),
                ")"
            )
        );
    }
}
